from django.apps import AppConfig


class books_appConfig(AppConfig):
    name = 'books_app'
